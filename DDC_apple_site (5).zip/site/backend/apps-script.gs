/**
 * DDC — приём откликов на вакансии + письмо HR (Google Apps Script).
 *
 * Зачем: чтобы отклики приходили в Google-таблицу И на почту HR
 * (с вложенным резюме), без своего сервера.
 *
 * Как подключить:
 *  1) Создайте Google-таблицу.
 *  2) Расширения → Apps Script. Удалите образец, вставьте этот код.
 *  3) Впишите HR_EMAIL ниже (куда присылать отклики).
 *  4) «Развернуть → Создать развёртывание → Веб-приложение»:
 *        Выполнять от имени: «я»,  Доступ: «Все».
 *  5) Скопируйте URL веб-приложения и впишите его в config.js:
 *        window.DDC_APPLY_ENDPOINT = 'СКОПИРОВАННЫЙ_URL';
 *
 * Примечание: Apps Script не отдаёт CORS-заголовки, поэтому сайт шлёт
 * отклик «вслепую» (fire-and-forget) — данные сохраняются и письмо
 * уходит, даже если браузер не читает ответ. Для полного контроля
 * статуса используйте вариант на Cloudflare Workers (см. DB_SETUP.md).
 */

var HR_EMAIL = 'info@bsbnb.kz'; // ← укажите адрес HR

function doPost(e) {
  try {
    var d = JSON.parse((e && e.postData && e.postData.contents) || '{}');

    // 1) строка в таблицу
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sh = ss.getSheetByName('Отклики') || ss.insertSheet('Отклики');
    if (sh.getLastRow() === 0)
      sh.appendRow(['Дата', 'Вакансия', 'Отдел', 'ФИО', 'Email', 'Телефон', 'Письмо', 'Резюме']);
    sh.appendRow([
      d.ts || new Date(), d.vacancy || '', d.department || '', d.name || '',
      d.email || '', d.phone || '', d.cover || '', d.resumeName || ''
    ]);

    // 2) письмо HR (с вложением резюме, если оно передано)
    var body = 'Новый отклик на вакансию\n\n'
      + 'Вакансия: ' + (d.vacancy || '') + '\n'
      + 'Отдел: '    + (d.department || '') + '\n'
      + 'ФИО: '      + (d.name || '') + '\n'
      + 'Email: '    + (d.email || '') + '\n'
      + 'Телефон: '  + (d.phone || '—') + '\n\n'
      + (d.cover || '');

    var opts = { name: 'DDC Careers', replyTo: d.email || HR_EMAIL };
    if (d.resumeData && d.resumeData.indexOf('base64,') > -1) {
      var parts = d.resumeData.split(',');
      var mime = ((parts[0] || '').match(/data:([^;]+)/) || [])[1] || 'application/octet-stream';
      opts.attachments = [Utilities.newBlob(Utilities.base64Decode(parts[1]), mime, d.resumeName || 'resume')];
    }
    MailApp.sendEmail(HR_EMAIL, 'Отклик: ' + (d.vacancy || 'вакансия') + ' — ' + (d.name || ''), body, opts);

    return ContentService.createTextOutput(JSON.stringify({ ok: true }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ ok: false, error: String(err) }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet() {
  return ContentService.createTextOutput('DDC apply endpoint OK');
}
